--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 15.2
-- Dumped by pg_dump version 15.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "CAR DEALERSHIP";
--
-- Name: CAR DEALERSHIP; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE "CAR DEALERSHIP" WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'English_United States.1252';


ALTER DATABASE "CAR DEALERSHIP" OWNER TO postgres;

\connect -reuse-previous=on "dbname='CAR DEALERSHIP'"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: pg_database_owner
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO pg_database_owner;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: pg_database_owner
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: insert_customer(character varying, character varying, character varying, character varying, character varying); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.insert_customer(IN _first_name character varying, IN _last_name character varying, IN _email character varying, IN _phone character varying, IN _address character varying)
    LANGUAGE plpgsql
    AS $$
	BEGIN 
		INSERT INTO customer(first_name, last_name, email, phone, address)
		VALUES(_first_name, _last_name,_email,  _phone, _address);
		COMMIT ;
	END;
$$;


ALTER PROCEDURE public.insert_customer(IN _first_name character varying, IN _last_name character varying, IN _email character varying, IN _phone character varying, IN _address character varying) OWNER TO postgres;

--
-- Name: insert_inventory(character varying, character varying, integer, character varying, character varying, numeric, character varying); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.insert_inventory(IN _make character varying, IN _model character varying, IN _year integer, IN _condition character varying, IN _vin character varying, IN _price numeric, IN _status character varying)
    LANGUAGE plpgsql
    AS $$
	BEGIN 
	INSERT INTO  inventory(make, model, "year", "condition", "VIN", price, status)
	VALUES (_make, _model, _year, _condition, _VIN, _price, _status);
	COMMIT;
	END;
$$;


ALTER PROCEDURE public.insert_inventory(IN _make character varying, IN _model character varying, IN _year integer, IN _condition character varying, IN _vin character varying, IN _price numeric, IN _status character varying) OWNER TO postgres;

--
-- Name: insert_invoice(integer, character varying, integer, numeric, date, integer); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.insert_invoice(IN _inventory_id integer, IN _vin character varying, IN _customer_id integer, IN _total numeric, IN _date date, IN _staff_id integer)
    LANGUAGE plpgsql
    AS $$
	BEGIN  
		UPDATE inventory SET  status = 'sold' WHERE inventory_id = _inventory_id  ;
		INSERT INTO invoice(inventory_id, "VIN",customer_id , total , "date" , staff_id  )
		VALUES(_inventory_id, _VIN, _customer_id, _total, _date, _staff_id);
		COMMIT ;
	END;
$$;


ALTER PROCEDURE public.insert_invoice(IN _inventory_id integer, IN _vin character varying, IN _customer_id integer, IN _total numeric, IN _date date, IN _staff_id integer) OWNER TO postgres;

--
-- Name: insert_sales_team(character varying, character varying, character varying); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.insert_sales_team(IN _first_name character varying, IN _last_name character varying, IN _phone character varying)
    LANGUAGE plpgsql
    AS $$
	BEGIN 
		INSERT INTO sales_team(first_name, last_name, phone)
		VALUES(_first_name, _last_name, _phone);
		COMMIT ;
	END;
$$;


ALTER PROCEDURE public.insert_sales_team(IN _first_name character varying, IN _last_name character varying, IN _phone character varying) OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: car; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.car (
    car_id integer NOT NULL,
    customer_id integer NOT NULL,
    history_id integer,
    vin character varying(55) NOT NULL,
    make character varying(20) NOT NULL,
    model character varying(20) NOT NULL,
    year character varying(4) NOT NULL,
    mile_age integer
);


ALTER TABLE public.car OWNER TO postgres;

--
-- Name: car_car_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.car_car_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.car_car_id_seq OWNER TO postgres;

--
-- Name: car_car_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.car_car_id_seq OWNED BY public.car.car_id;


--
-- Name: customer; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.customer (
    customer_id integer NOT NULL,
    first_name character varying(20) NOT NULL,
    last_name character varying(20),
    email character varying(100),
    phone character varying(20),
    address character varying(100)
);


ALTER TABLE public.customer OWNER TO postgres;

--
-- Name: customer_customer_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.customer_customer_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.customer_customer_id_seq OWNER TO postgres;

--
-- Name: customer_customer_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.customer_customer_id_seq OWNED BY public.customer.customer_id;


--
-- Name: history; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.history (
    history_id integer NOT NULL,
    ticket_id integer
);


ALTER TABLE public.history OWNER TO postgres;

--
-- Name: history_history_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.history_history_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.history_history_id_seq OWNER TO postgres;

--
-- Name: history_history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.history_history_id_seq OWNED BY public.history.history_id;


--
-- Name: inventory; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.inventory (
    inventory_id integer NOT NULL,
    make character varying(20) NOT NULL,
    model character varying(20) NOT NULL,
    year character varying(4) NOT NULL,
    condition character varying(20) NOT NULL,
    "VIN" character varying(20) NOT NULL,
    price numeric(8,2) NOT NULL,
    status character varying(55) NOT NULL
);


ALTER TABLE public.inventory OWNER TO postgres;

--
-- Name: inventory_inventory_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.inventory_inventory_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.inventory_inventory_id_seq OWNER TO postgres;

--
-- Name: inventory_inventory_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.inventory_inventory_id_seq OWNED BY public.inventory.inventory_id;


--
-- Name: invoice; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.invoice (
    invoice_id integer NOT NULL,
    inventory_id integer NOT NULL,
    "VIN" character varying(255) NOT NULL,
    customer_id integer NOT NULL,
    total numeric(8,2) NOT NULL,
    date date NOT NULL,
    staff_id integer NOT NULL
);


ALTER TABLE public.invoice OWNER TO postgres;

--
-- Name: invoice_invoice_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.invoice_invoice_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.invoice_invoice_id_seq OWNER TO postgres;

--
-- Name: invoice_invoice_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.invoice_invoice_id_seq OWNED BY public.invoice.invoice_id;


--
-- Name: mechanics; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.mechanics (
    mech_id integer NOT NULL,
    first_name character varying(20) NOT NULL,
    last_name character varying(20) NOT NULL,
    phone character varying(20) NOT NULL,
    title character varying(50)
);


ALTER TABLE public.mechanics OWNER TO postgres;

--
-- Name: mechanics_mech_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.mechanics_mech_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.mechanics_mech_id_seq OWNER TO postgres;

--
-- Name: mechanics_mech_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.mechanics_mech_id_seq OWNED BY public.mechanics.mech_id;


--
-- Name: repair; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.repair (
    ticket_id integer NOT NULL,
    customer_id integer NOT NULL,
    car_id integer NOT NULL,
    service_id integer NOT NULL,
    repair_mechanics_id integer NOT NULL,
    total numeric(8,2) NOT NULL,
    date date NOT NULL
);


ALTER TABLE public.repair OWNER TO postgres;

--
-- Name: repair_mechanics; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.repair_mechanics (
    repair_mechanics_id integer NOT NULL,
    ticket_id integer NOT NULL,
    mech1_id integer,
    mech2_id integer,
    mech3_id integer
);


ALTER TABLE public.repair_mechanics OWNER TO postgres;

--
-- Name: repair_mechanics_repair_mechanics_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.repair_mechanics_repair_mechanics_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.repair_mechanics_repair_mechanics_id_seq OWNER TO postgres;

--
-- Name: repair_mechanics_repair_mechanics_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.repair_mechanics_repair_mechanics_id_seq OWNED BY public.repair_mechanics.repair_mechanics_id;


--
-- Name: repair_ticket_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.repair_ticket_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.repair_ticket_id_seq OWNER TO postgres;

--
-- Name: repair_ticket_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.repair_ticket_id_seq OWNED BY public.repair.ticket_id;


--
-- Name: sales_team; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sales_team (
    staff_id integer NOT NULL,
    first_name character varying(20) NOT NULL,
    last_name character varying(20) NOT NULL,
    phone character varying(20) NOT NULL
);


ALTER TABLE public.sales_team OWNER TO postgres;

--
-- Name: sales_team_staff_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.sales_team_staff_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.sales_team_staff_id_seq OWNER TO postgres;

--
-- Name: sales_team_staff_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.sales_team_staff_id_seq OWNED BY public.sales_team.staff_id;


--
-- Name: services; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.services (
    service_id integer NOT NULL,
    name character varying(100) NOT NULL,
    total numeric(8,2) NOT NULL
);


ALTER TABLE public.services OWNER TO postgres;

--
-- Name: services_service_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.services_service_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.services_service_id_seq OWNER TO postgres;

--
-- Name: services_service_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.services_service_id_seq OWNED BY public.services.service_id;


--
-- Name: car car_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.car ALTER COLUMN car_id SET DEFAULT nextval('public.car_car_id_seq'::regclass);


--
-- Name: customer customer_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customer ALTER COLUMN customer_id SET DEFAULT nextval('public.customer_customer_id_seq'::regclass);


--
-- Name: history history_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.history ALTER COLUMN history_id SET DEFAULT nextval('public.history_history_id_seq'::regclass);


--
-- Name: inventory inventory_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inventory ALTER COLUMN inventory_id SET DEFAULT nextval('public.inventory_inventory_id_seq'::regclass);


--
-- Name: invoice invoice_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.invoice ALTER COLUMN invoice_id SET DEFAULT nextval('public.invoice_invoice_id_seq'::regclass);


--
-- Name: mechanics mech_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mechanics ALTER COLUMN mech_id SET DEFAULT nextval('public.mechanics_mech_id_seq'::regclass);


--
-- Name: repair ticket_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.repair ALTER COLUMN ticket_id SET DEFAULT nextval('public.repair_ticket_id_seq'::regclass);


--
-- Name: repair_mechanics repair_mechanics_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.repair_mechanics ALTER COLUMN repair_mechanics_id SET DEFAULT nextval('public.repair_mechanics_repair_mechanics_id_seq'::regclass);


--
-- Name: sales_team staff_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sales_team ALTER COLUMN staff_id SET DEFAULT nextval('public.sales_team_staff_id_seq'::regclass);


--
-- Name: services service_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.services ALTER COLUMN service_id SET DEFAULT nextval('public.services_service_id_seq'::regclass);


--
-- Data for Name: car; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.car (car_id, customer_id, history_id, vin, make, model, year, mile_age) FROM stdin;
\.
COPY public.car (car_id, customer_id, history_id, vin, make, model, year, mile_age) FROM '$$PATH$$/3428.dat';

--
-- Data for Name: customer; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.customer (customer_id, first_name, last_name, email, phone, address) FROM stdin;
\.
COPY public.customer (customer_id, first_name, last_name, email, phone, address) FROM '$$PATH$$/3416.dat';

--
-- Data for Name: history; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.history (history_id, ticket_id) FROM stdin;
\.
COPY public.history (history_id, ticket_id) FROM '$$PATH$$/3426.dat';

--
-- Data for Name: inventory; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.inventory (inventory_id, make, model, year, condition, "VIN", price, status) FROM stdin;
\.
COPY public.inventory (inventory_id, make, model, year, condition, "VIN", price, status) FROM '$$PATH$$/3412.dat';

--
-- Data for Name: invoice; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.invoice (invoice_id, inventory_id, "VIN", customer_id, total, date, staff_id) FROM stdin;
\.
COPY public.invoice (invoice_id, inventory_id, "VIN", customer_id, total, date, staff_id) FROM '$$PATH$$/3418.dat';

--
-- Data for Name: mechanics; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.mechanics (mech_id, first_name, last_name, phone, title) FROM stdin;
\.
COPY public.mechanics (mech_id, first_name, last_name, phone, title) FROM '$$PATH$$/3422.dat';

--
-- Data for Name: repair; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.repair (ticket_id, customer_id, car_id, service_id, repair_mechanics_id, total, date) FROM stdin;
\.
COPY public.repair (ticket_id, customer_id, car_id, service_id, repair_mechanics_id, total, date) FROM '$$PATH$$/3424.dat';

--
-- Data for Name: repair_mechanics; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.repair_mechanics (repair_mechanics_id, ticket_id, mech1_id, mech2_id, mech3_id) FROM stdin;
\.
COPY public.repair_mechanics (repair_mechanics_id, ticket_id, mech1_id, mech2_id, mech3_id) FROM '$$PATH$$/3430.dat';

--
-- Data for Name: sales_team; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sales_team (staff_id, first_name, last_name, phone) FROM stdin;
\.
COPY public.sales_team (staff_id, first_name, last_name, phone) FROM '$$PATH$$/3414.dat';

--
-- Data for Name: services; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.services (service_id, name, total) FROM stdin;
\.
COPY public.services (service_id, name, total) FROM '$$PATH$$/3420.dat';

--
-- Name: car_car_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.car_car_id_seq', 2, true);


--
-- Name: customer_customer_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.customer_customer_id_seq', 3, true);


--
-- Name: history_history_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.history_history_id_seq', 1, false);


--
-- Name: inventory_inventory_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.inventory_inventory_id_seq', 3, true);


--
-- Name: invoice_invoice_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.invoice_invoice_id_seq', 2, true);


--
-- Name: mechanics_mech_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.mechanics_mech_id_seq', 3, true);


--
-- Name: repair_mechanics_repair_mechanics_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.repair_mechanics_repair_mechanics_id_seq', 1, false);


--
-- Name: repair_ticket_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.repair_ticket_id_seq', 1, false);


--
-- Name: sales_team_staff_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.sales_team_staff_id_seq', 3, true);


--
-- Name: services_service_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.services_service_id_seq', 3, true);


--
-- Name: car car_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.car
    ADD CONSTRAINT car_pkey PRIMARY KEY (car_id);


--
-- Name: customer customer_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customer
    ADD CONSTRAINT customer_pkey PRIMARY KEY (customer_id);


--
-- Name: history history_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.history
    ADD CONSTRAINT history_pkey PRIMARY KEY (history_id);


--
-- Name: history history_ticket_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.history
    ADD CONSTRAINT history_ticket_id_key UNIQUE (ticket_id);


--
-- Name: inventory inventory_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inventory
    ADD CONSTRAINT inventory_pkey PRIMARY KEY (inventory_id);


--
-- Name: invoice invoice_inventory_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.invoice
    ADD CONSTRAINT invoice_inventory_id_key UNIQUE (inventory_id);


--
-- Name: invoice invoice_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.invoice
    ADD CONSTRAINT invoice_pkey PRIMARY KEY (invoice_id);


--
-- Name: mechanics mechanics_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mechanics
    ADD CONSTRAINT mechanics_pkey PRIMARY KEY (mech_id);


--
-- Name: repair_mechanics repair_mechanics_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.repair_mechanics
    ADD CONSTRAINT repair_mechanics_pkey PRIMARY KEY (repair_mechanics_id);


--
-- Name: repair repair_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.repair
    ADD CONSTRAINT repair_pkey PRIMARY KEY (ticket_id);


--
-- Name: sales_team sales_team_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sales_team
    ADD CONSTRAINT sales_team_pkey PRIMARY KEY (staff_id);


--
-- Name: services services_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.services
    ADD CONSTRAINT services_pkey PRIMARY KEY (service_id);


--
-- Name: car car_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.car
    ADD CONSTRAINT car_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customer(customer_id);


--
-- Name: car car_history_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.car
    ADD CONSTRAINT car_history_id_fkey FOREIGN KEY (history_id) REFERENCES public.history(history_id);


--
-- Name: repair car_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.repair
    ADD CONSTRAINT car_id FOREIGN KEY (car_id) REFERENCES public.car(car_id);


--
-- Name: history history_ticket_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.history
    ADD CONSTRAINT history_ticket_id_fkey FOREIGN KEY (ticket_id) REFERENCES public.repair(ticket_id);


--
-- Name: invoice invoice_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.invoice
    ADD CONSTRAINT invoice_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customer(customer_id);


--
-- Name: invoice invoice_inventory_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.invoice
    ADD CONSTRAINT invoice_inventory_id_fkey FOREIGN KEY (inventory_id) REFERENCES public.inventory(inventory_id);


--
-- Name: invoice invoice_staff_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.invoice
    ADD CONSTRAINT invoice_staff_id_fkey FOREIGN KEY (staff_id) REFERENCES public.sales_team(staff_id);


--
-- Name: repair repair_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.repair
    ADD CONSTRAINT repair_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customer(customer_id);


--
-- Name: repair repair_mechanics_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.repair
    ADD CONSTRAINT repair_mechanics_id FOREIGN KEY (repair_mechanics_id) REFERENCES public.repair_mechanics(repair_mechanics_id);


--
-- Name: repair_mechanics repair_mechanics_mech1_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.repair_mechanics
    ADD CONSTRAINT repair_mechanics_mech1_id_fkey FOREIGN KEY (mech1_id) REFERENCES public.mechanics(mech_id);


--
-- Name: repair_mechanics repair_mechanics_mech2_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.repair_mechanics
    ADD CONSTRAINT repair_mechanics_mech2_id_fkey FOREIGN KEY (mech2_id) REFERENCES public.mechanics(mech_id);


--
-- Name: repair_mechanics repair_mechanics_mech3_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.repair_mechanics
    ADD CONSTRAINT repair_mechanics_mech3_id_fkey FOREIGN KEY (mech3_id) REFERENCES public.mechanics(mech_id);


--
-- Name: repair repair_service_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.repair
    ADD CONSTRAINT repair_service_id_fkey FOREIGN KEY (service_id) REFERENCES public.services(service_id);


--
-- PostgreSQL database dump complete
--

